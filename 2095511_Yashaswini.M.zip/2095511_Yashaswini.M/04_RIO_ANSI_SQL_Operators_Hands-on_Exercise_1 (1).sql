use RIO2;
select * from Trainer_Info where Trainer_Email is null;
/*-----------------------------(END OF PROBLEM 1)----------------------------------------------*/

select Trainer_Id, Trainer_Name, Trainer_Track, Trainer_Location from Trainer_Info where Trainer_Experience>4;
 /*-----------------------------(END OF PROBLEM 2)----------------------------------------------*/

select * from Module_Info where Module_Duration>200;
 /*-----------------------------(END OF PROBLEM 3)----------------------------------------------*/

select Trainer_Id, Trainer_Name from Trainer_Info where Trainer_Qualification != 'Bachelor of technology';
/*-------------------------------(END OF PROBLEM 4)----------------------------------------------*/
 
select Module_Name from Module_Info where Module_Duration between 200 and 300;
/*-----------------------------(END OF PROBLEM 5)----------------------------------------------*/

select Trainer_Id, Trainer_Name from Trainer_Info where Trainer_Name like 'M%';
/*-----------------------------(END OF PROBLEM 6)----------------------------------------------*/

select Trainer_Id, Trainer_Name from Trainer_Info where Trainer_Name like '%o%';
/*-----------------------------(END OF PROBLEM 7)----------------------------------------------*/

select Module_Name from Module_Info where Module_Name is not null;
/*-----------------------------(END OF PROBLEM 8)----------------------------------------------*/

