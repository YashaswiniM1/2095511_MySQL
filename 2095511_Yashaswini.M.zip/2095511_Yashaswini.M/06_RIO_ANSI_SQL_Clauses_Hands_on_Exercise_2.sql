use UMS;
/*-------------------------------------Problem # 1:Write aquery which displays the student name, registration number and 
														their GPA in descending order of GPA.-------------------------------------*/
select si.SName, si.REgNo, sresult.GPA from Student_Info as si
inner join Student_Result as sresult on sresult.RegNo = si.RegNo
order by sresult.GPA desc;

/*-----------------------------------Problem # 2:Write a query which displays the student information in ascending order of the student’s name.-----------------------------------*/
select * from Student_Info order by SName asc;

/*-------------------------------------Problem # 3:Write a query which displays the information of students in ascending order of their age.-------------------------------------*/
select * from Student_Info order by datediff(Date_of_Joining, Date_of_Birth) asc;

/*-------------------------------------Problem # 4:Write a query to display the registration number, student name, semester number 
                                                  and GPA of students such that students with high GPA are displayed on top.-------------------------------------*/
select si.RegNo, si.SName, SemNo, GPA from Student_Info as si
inner join Student_Result as sresult on sresult.RegNo = si.RegNo
order by sresult.GPA desc;

/*-------------------------------------Problem # 5:Write a query to display the registration number and GPA of each student.-------------------------------------*/
select RegNo, GPA from Student_Result order by Scholarship_Eligibility desc;

/*-------------------------------------Problem # 6:Write a query to display the registration number and GPA of each student in
										such a way that the students who are eligible for scholarship are displayed first.-------------------------------------*/
select RegNo, GPA from Student_Result order by Scholarship_Eligibility desc;

/*-------------------------------------Problem # 7:Write a query to display the details of students who have secured maximum 
                                                                              GPA in each semester. Hint: Use GROUPBY.-------------------------------------*/
select * from Student_Info as si
inner join Student_Result as sresult on sresult.RegNo = si.RegNo
where sresult.GPA in (select max(GPA) from Student_Result group by SemNo);

/*-------------------------------------Problem # 8:Write a query to display the details of students who have secured mimimum
                                                                               GPA in each semester. Hint: Use GROUPBY.-------------------------------------*/
select * from Student_Info as sinfo
inner join Student_Result as sresult on sresult.RegNo = si.RegNo
where sresult.GPA in (select  min(GPA) from Student_Result group by SemNo);