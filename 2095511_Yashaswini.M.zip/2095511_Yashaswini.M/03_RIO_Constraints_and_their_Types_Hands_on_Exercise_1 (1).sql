create database RIO3_1;
USE RIO3_1;

create table Trainer_Info(
Trainer_Id varchar(30) not null primary key check(Trainer_Id like 'F%'),
Salutation varchar(7) not null,
Trainer_Name varchar(30) not null,
Trainer_Location varchar(30)not null,
Trainer_Track varchar(15) not null,
Trainer_Qualification varchar(100) not null,
Trainer_Experience int,
Trainer_Email varchar(100) not null,
Trainer_Password varchar(20) not null
);

create table Batch_Info(
Batch_Id varchar(20)not null primary key check(Batch_Id like 'B%'),
Batch_Owner varchar(30)not null,
Batch_BU_Name varchar(30) not null
);

create table Module_Info(
Module_Id varchar(20)not null primary key check(upper(Module_Id)=Module_Id),
Module_Name varchar(40)not null,
Module_Duration int not null
);

create table Associate_Info(
Associate_Id varchar(20)not null primary key check(Associate_Id like 'A%'),
Salutation varchar(7) not null,
Associate_Name varchar(30)not null,
Associate_Location varchar(30) not null,
Associate_Track varchar(15) not null,
Associate_Qualification varchar(200) not null,
Associate_Email varchar(100) not null,
Associate_Password varchar(20) not null
);

create table Questions(
Question_Id varchar(20)not null primary key check(Question_Id like 'Q%'),
Module_Id varchar(20), foreign key (Module_Id) REFERENCES Module_Info(Module_Id),
Question_Text varchar(900) not null
);

create table Associate_Status(
Associate_Id varchar(20) not null, foreign key (Associate_Id) REFERENCES Associate_Info(Associate_Id),
Module_Id varchar(20) not null, foreign key (Module_Id) REFERENCES Module_Info(Module_Id),
Batch_Id varchar(20)not null, foreign key (Batch_Id) REFERENCES Batch_Info(Batch_Id),
Trainer_Id varchar(20)not null, foreign key (Trainer_Id) REFERENCES Trainer_Info(Trainer_Id),
Start_Date varchar(20),
End_Date varchar(20),
AFeedbackGiven varchar(20),
TFeedbackGiven varchar(20)
);

create table Trainer_Feedback(
Trainer_Id varchar(20)not null, foreign key(Trainer_Id) REFERENCES Trainer_Info(Trainer_Id),
Question_Id varchar(20)not null, foreign key(Question_Id) REFERENCES Questions(Question_Id),
Batch_Id varchar(20)not null, foreign key(Batch_Id) REFERENCES Batch_Info(Batch_Id),
Module_Id varchar(20)not null, foreign key (Module_Id) REFERENCES Module_Info(Module_Id),
Trainer_Rating int not null
);

create table Associate_Feedback(
Associate_Id varchar(20)not null, foreign key(Associate_Id) REFERENCES Associate_Info(Associate_Id),
Question_Id varchar(20)not null, foreign key(Question_Id) REFERENCES Questions(Question_Id),
Module_Id varchar(20)not null, foreign key(Module_Id) REFERENCES Module_Info(Module_Id),
Associate_Rating int not null
);

/*-----------------------------------------(END_OF_EXERCISE_3.1)---------------------------------------*/

create table Product( ProductID int primary key, ProductName varchar(20), ProductPrice int not null);
create table username (UserID varchar(10) primary key, ProductID int, username varchar(20), foreign key(ProductID) references Product(ProductID)); 

insert into Product values(1,'A Dongle',290),(2,'B Dongle',1250);
insert into Product (ProductID, ProductName, ProductPrice) values (3,'C Dongle',0);
select * from Product;

set foreign_key_checks = 1;
select * from username;
drop table username;
insert into username (UserID, ProductID, username) values('U001',1,'Ramesh'),('U002',11,'Mahesh');

/*-------------------------------------------(END_OF_EXERCISE_3.2)-----------------------------------------*/