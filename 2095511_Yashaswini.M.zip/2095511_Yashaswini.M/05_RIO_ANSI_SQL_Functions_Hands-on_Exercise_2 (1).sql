use UMS;
/*---------------------- Problem # 1:Write a query to display student information such as name, branch in capital letters.----------------------*/
select upper(SName), upper(Branch) from Student_Info;

/*---------------------- Problem # 2:Write a query to displays all details in subject_master in small letters.----------------------*/
select lower(Subject_Code), lower(Subject_Name), lower(Weightage) from Subject_Master;

/*---------------------- Problem # 3:Write two separate queries to display the registration number date of birth 
                                          of all the students in the following formats----------------------*/
-- • 2011/07/23
select RegNo, date_format(Date_of_Birth,'%Y/%m/%d') from Student_Info;
-- • July 23, 2011
select RegNo, date_format(Date_of_Birth, '%M %d, %Y') from Student_Info;

/*---------------------- Problem # 4:Write a query to display age of each student along with name, contact number and email id.
                                   Age = Number of months between DOB and current date /12. ----------------------*/
select SName, (period_diff(extract(year_month from current_date), extract(year_month from Date_of_Birth))/12)
 as Age, Contact_Number, Email_Id from Student_Info;

/*---------------------- Problem # 5:Write a query to display the registration number, student name and average marks secured 
                                                   by students in each semester.----------------------*/
select RegNo, SName, 
(select avg(marks) from Student_Marks as smarks where smarks.RegNo = si.RegNo) 
from Student_Info as si;

/*---------------------- Problem # 6:Pick the maximum mark from the students_marks and display the student registration 
                           number and name of those students who have secured the maximum mark.----------------------*/
select smarks.RegNo, si.SName, max(Marks) from Student_Info as si
inner join Student_Marks as smarks on smarks.RegNo = si.RegNo
group by smarks.Subject_Code;

/*---------------------- Problem # 7:Pick the maximum marks secured in the subject “ EI05IP” and display the student name
                                 and registration number of the student who has secured it.----------------------*/
select SName , max(Marks) from Student_Info as si
inner join Student_Marks as smarks on si.RegNo = smarks.RegNo
where Subject_Code = 'EI05IP';

/*----------------------Problem # 8:Write a query to display the average GPA for each semester. Display the semester number and the average.
	Hint: Average = Total GPA of all students in a semester/total number of students in a semester. Rule: Use AVG function ----------------------*/
select SemNo, avg(GPA) from Student_Result group by SemNo;

/*---------------------- Problem # 9:display all the student records, if the student email id is null it should be displayed 
                                                 as “no valid email address”.----------------------*/
select SName, RegNo, Branch, Contact_Number, Date_of_Birth, Date_of_Joining, Address,
case when Email_Id is null then 'no valid email address'
else Email_Id end as Email_id   from Student_Info;

/*---------------------- Problem # 10:Write a query which will display the student name, branch, registration number, 
              semester number and result. Display the full name of EEE as well as ECE branch as mentioned below, 
              If EEE then ‘Electrical and Electronic Engineering’ If ECE then Electronics and Communication Engineering.----------------------*/
select SName, case when Branch = 'EEE' then 'Electrical and Electronic Engineering'
                     when Branch = 'ECE' then 'Electronics and Communication Engineering'
                     else Branch end as Branch, si.RegNo, sresult.SemNo, sresult.GPA from Student_Info as si
inner join Student_Result as sresult on sresult.RegNo = si.RegNo;