/*-----------------------------------Problem Statement:Write a query to pick up the maximum marks from students marks table and display
                                                     the student registration number and name of those students who have secured the maximum marks.-----------------------------------*/
select si.Student_Name, Marks, sm.RegNo, Subject_Code from Student_Marks as sm
inner join Student_Info as si on si.RegNo = sm.RegNo
where sm.RegNo in (select RegNo from Student_Marks group by Subject_Code having max(Marks));

/*-----------------------------------Problem Statement:Write a query to pick up the maximum marks secured in the subject “EI05IP” and display
                                                                        the student nameand registration number of the student who has secured it.-----------------------------------*/
select si.RegNo , si.SName, sm.Marks from Student_Marks as sm
inner join Student_Info as si on si.RegNo = sm.RegNo
where sm.RegNo in (select RegNo from Student_Marks group by Subject_Code having max(Marks)) and Subject_Code = 'EI05IP'; 

/*-----------------------------------Problem Statement:Write a query to display the student name and registration number of the student
                                                                              who has secured second highest marks in the subject El05lP subject.-----------------------------------*/
select Student_Name, RegNo from Student_Info 
where RegNo = (select RegNo from Student_Marks where Subject_Code = 'EI05IP'
order by Marks desc
limit 1 offset 1);

/*-----------------------------------Problem Statement:Write a query to display registration numbers of those students who scored
                                                           more than the average score scored by students in the subject El05lP.-----------------------------------*/
select RegNo from Student_Marks where Marks > 
(select avg(Marks) from Student_Marks where Subject_Code = 'EI05IP');