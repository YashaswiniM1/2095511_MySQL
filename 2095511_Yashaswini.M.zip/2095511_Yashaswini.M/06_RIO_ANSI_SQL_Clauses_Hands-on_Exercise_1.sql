use RIO2;
create table Employee_Info (Employee_Id varchar(20), Employee_Name varchar(30), Date_of_Joining date, Age int, Salary double);
select *from Employee_Info;
insert into Employee_Info values
('F001','Ram','2021-12-01', 23, 25000.00),
('F002', 'Sham','2021-12-03', 25, 23000.00),
('F003', 'Vinod','2021-12-05', 24, 22500.00),
('F004','kumar','2021-12-21', 25, 23000.00),
('F005','Raj','2021-12-15', 23, 24000.00),
('F006', 'dev','2021-12-01', 26, 24500.00),
('F007','shiv', '2021-12-03',29, 24000.00),
('F008','manju','2021-12-19',27,23000.00),
('F009',' Prem','2021-12-19', 28, 26000.00),
('F0010','karan','2021-12-05',30,28000.00);
select Age from Employee_Info;
select Date_of_Joining, count(Employee_Id)
from Employee_Info where Employee_Id='F001' group by Date_of_Joining;
select Date_of_Joining, count(Employee_Id)
from Employee_Info where Employee_Id='F001'
group by Date_of_Joining having count(Employee_Id)>=2;
select Age from Employee_Info order by Age;
select Employee_Id, Employee_Name, Salary from Employee_Info order by Salary desc;