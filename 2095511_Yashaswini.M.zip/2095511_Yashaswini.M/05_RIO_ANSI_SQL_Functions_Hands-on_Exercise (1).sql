use RIO2;
/*----------------------Problem 1: Develop a query which will display the module name and module Infra fees of the entire
                                          module.The infra fee should be rounded to 2 decimal point.----------------------------*/
select * from Module_Info;
select Module_Name, truncate(Module_Fees,2)from  Module_Info;

/*----------------------Problem 2: Develop a query which will list all the module id and module names in Module_Info table
                                         where in the first letter should be capital letter.----------------------------*/
select * from Module_Info ;
select Module_Id, Module_Name from Module_Info where substring(Module_Name,1,1) = binary upper(substring(Module_Name,1,1));

/*----------------------Problem 3: Develop a query which will display the module id and the number of days 
                         between the current date and module start date in associate_status table----------------------------*/
select Module_Id, Start_Date, datediff(current_date(), Start_Date) from Associate_Status;

/*----------------------Problem 4: Develop a query which will concatenate the Module Name and Module id in the 
                          following format and display all the modules in the module_info table.
                                 “< Module Name><Module id>”----------------------------*/
select concat_ws('><',concat_ws('<','',Module_Name),concat_ws('>',Module_Id,'')) from Module_Info ;

/*----------------------Problem 5: Develop a query which will display all the Module Name in upper case.----------------------------*/
select upper(Module_Name) from Module_Info;

/*----------------------Problem 6: Develop a query which will display all the characters between 1 and 3 of the Module name 
                             column for all the modules in the Module_Info table.----------------------------*/
select substring(Module_Name,1,3) as Module_Name from Module_Info;

/*----------------------Problem 7: Develop a query calculate average of all the module base fees, 
                     any records whose base fee is null needs to be considered as zero.----------------------------*/
select sum(ifnull(Module_Fees,0))/count(*) as average from Module_Info;

/*----------------------Problem 8: Write a query which will convert Trainer_Info’s Trainer_Id to Number and add 100000 and 
                 display it for all the trainers in the Trainer_Info table.----------------------------*/
select * from Trainer_Info;
select convert(Trainer_Id+100000,unsigned) as display from Trainer_Info;

/*---------------------- Problem 9:Write a query which will convert Base_Fees into Varchar from the Module_info table.
     And display in the following format ‘The Base Fees Amount for the module name’ <Module Name>’ is ’<Base Fees>----------------------------*/
select concat('The Base Fees Amount for the module name ',convert(Module_Name, char),' is ',
convert(Module_Fees, char)) as Fees from Module_Info;

/*----------------------Problem 10: Write a query which will display the total number of records in Module_Info table----------------------------*/
select count(*) from Module_Info;

/*----------------------Problem 11: Develop a query which will give the sum of all base fees of all modules in the Module_Fees table----------------------------*/
select sum(ifnull(Module_Fees,0)) from Module_Info;

/*----------------------Problem 12: Display the minimum and maximum base fees of the modules----------------------------*/
select min(ifnull(Module_Fees,0)) as minimum , max(Module_Fees) as maximum from Module_Info;