use UMS;
select * from Student_Info where Email_Id is not null;
/*---------------------------------------(END OF PROBLEM 1)--------------------------------------------*/

select Marks, RegNo from Student_Marks where Marks>50;
/*---------------------------------------(END OF PROBLEM 2)--------------------------------------------*/

select si.RegNo, si.SName, smaster.Subject_Name, smarks.SemNo, smarks.Marks from Student_Marks as smarks
inner join Student_Info as si on si.RegNo = smarks.RegNo
inner join Subject_Master as smaster on smaster.Subject_Code = smarks.Subject_code;
/*---------------------------------------(END OF PROBLEM 3)--------------------------------------------*/

select si.SName, si.RegNo, smaster.Subject_Code, smaster.Subject_Name, smarks.Marks, smarks.SemNo from Student_Marks as smarks
inner join Student_Info as si on si.RegNo = smarks.RegNo 
inner join Subject_Master as smaster on smaster.Subject_Code = smarks.Subject_Code
where smarks.Marks >50; 
/*---------------------------------------(END OF PROBLEM 4)--------------------------------------------*/

select RegNo, GPA , Scholarship_Eligibility from Student_Result order by Scholarship_Eligibility desc;
/*---------------------------------------(END OF PROBLEM 5)--------------------------------------------*/

select si.RegNo, si.SName, smarks.Marks, (smaster.Weightage* smarks.Marks/100) as Weighted_Marks from Student_Marks as smarks
inner join Subject_Master as smaster on smarks.Subject_Code  = smaster.Subject_Code 
inner join Student_Info as si on si.RegNo = smarks.RegNo ;
/*---------------------------------------(END OF PROBLEM 6)--------------------------------------------*/

select SName from Student_Info where SName like 'm%';
/*---------------------------------------(END OF PROBLEM 7)--------------------------------------------*/

select si.SName, si.RegNo, smarks.Marks from Student_Info as si
inner join Student_Marks as smarks on smarks.RegNo = si.RegNo
where si.Email_Id is not null;
/*---------------------------------------(END OF PROBLEM 8)--------------------------------------------*/

select si.SName, si.RegNo, smarks.Marks from Student_Marks as smarks
inner join Student_Info as si on si.RegNo = smarks.RegNo
where smarks.Marks >= 60 and smarks.Marks <= 100;
/*---------------------------------------(END OF PROBLEM 9)--------------------------------------------*/

select si.SName, si.RegNo, smarks.Marks from Student_Info as si
inner join Student_Marks as smarks on si.RegNo = smarks.RegNo
where SName not like 'j%';
/*---------------------------------------(END OF PROBLEM 10)--------------------------------------------*/

select si.SName, si.RegNo, smarks.Marks from Student_Marks as smarks
inner join Student_Info as si on si.RegNo = smarks.RegNo
where smarks.Subject_Code in ('EE01DCF', 'EC02MUP');
/*---------------------------------------(END OF PROBLEM 11)--------------------------------------------*/

select SName from Student_Info where SName like '%on';
/*---------------------------------------(END OF PROBLEM 12)--------------------------------------------*/