use UMS;
alter table Student_Info modify RegNo varchar(20) primary key;
alter table Student_Info modify Date_of_Joining date default(current_date);
alter table Student_Info modify SName varchar(30) not null;
alter table Student_Info modify Branch varchar(20);
alter table Student_Info modify Contact_Number varchar(20);

-- a. Subject_Code- Primarykey-varchar2(10)
alter table Subject_Master modify Subject_Code varchar(20) primary key; 
-- b. Subject_Name- Varchar, not null
alter table Subject_Master modify Subject_Name varchar(30) not null;
-- c. Weightage- Number(3), not null
alter table Subject_Master modify Weightage int not null; 

-- c. Semester-Number(3) not null
alter table Student_Marks modify SemNo int not null;
-- d. Marks-Number (3) default value 0
alter table Student_Marks modify Marks smallint default 0;
alter table Student_Marks modify RegNo varchar(20);
alter table Student_Marks modify Subject_Code varchar(20);
-- a. Register-Number-Foreignkey (Student_Info) - Varchar
alter table Student_Marks add foreign key(RegNo) references Student_Info (RegNo); 
-- b. Subject_Code-Foreignkey (Subject_Master)-varchar2(10)
alter table Student_Marks add foreign key (Subject_Code) references Subject_Master (Subject_Code);
-- b. Semester-Number(3) Not null

alter table Student_Result modify SemNo int not null; 
-- c. GPA-Number (5,3)- Not Null
alter table Student_Result modify GPA decimal(5,3) not null;
-- d. Scholarship_Eligibility char(3) Default value is Yes
alter table Student_Result modify Scholarship_Eligibility varchar(3) default 'yes';

-- a) Create a constraint which does not allow repeated entries of subjects having the same Subject Name.
alter table Subject_Master add constraint con1_ unique (Subject_Name); 
-- b) Create a constraint which does not allow two students having the same Contact Number.
alter table Student_Info add constraint con2_ unique (Contact_Number);
-- c) Create a constraint which does not allow date of birth after date of joining.
alter table Student_Info add check (datediff (Date_of_Joining, Date_of_Birth)>0);
-- d) Create a constraint that does not allow value greater than 100 be inserted into Marks.
alter table Student_Marks add check (Marks <= 100);
-- e) Create a constraint which mandates GPA values to be less than or equal to 10.
alter table Student_Result add check (GPA <= 10);
-- f) Create a constraint which mandates that value for Scholarship_Eligibility is either ‘Y’ or ‘N’.
alter table Student_Result add check (Scholarship_Eligibility in ('y','n'));


